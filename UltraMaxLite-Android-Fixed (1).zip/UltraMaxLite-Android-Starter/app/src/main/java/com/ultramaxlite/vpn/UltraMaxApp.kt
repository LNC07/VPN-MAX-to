package com.ultramaxlite.vpn
import android.app.Application
class UltraMaxApp : Application()
