package com.ultramaxlite.vpn.crypto
import android.os.Build
import android.util.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.security.*
import java.security.spec.NamedParameterSpec
object X25519Util {
    private fun ensureBC() { if (Security.getProvider("BC") == null) Security.addProvider(BouncyCastleProvider()) }
    data class KeyPairB64(val privateKey: String, val publicKey: String)
    fun generate(): KeyPairB64 {
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                val kpg = KeyPairGenerator.getInstance("XDH"); kpg.initialize(NamedParameterSpec("X25519"))
                val kp = kpg.generateKeyPair()
                KeyPairB64(Base64.encodeToString(kp.private.encoded, Base64.NO_WRAP), Base64.encodeToString(kp.public.encoded, Base64.NO_WRAP))
            } else {
                ensureBC(); val kpg = KeyPairGenerator.getInstance("X25519", "BC"); val kp = kpg.generateKeyPair()
                KeyPairB64(Base64.encodeToString(kp.private.encoded, Base64.NO_WRAP), Base64.encodeToString(kp.public.encoded, Base64.NO_WRAP))
            }
        } catch (e: Exception) { throw RuntimeException("X25519 generation failed: ${e.message}", e) }
    }
}
